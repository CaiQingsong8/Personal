import SwiftUI

struct MonthView: View {
    @EnvironmentObject private var store: AppStore
    private let weekdays = ["一", "二", "三", "四", "五", "六", "日"]

    var body: some View {
        VStack(spacing: 12) {
            monthHeader

            HStack(spacing: 4) {
                ForEach(weekdays, id: \.self) { day in
                    Text(day)
                        .font(.caption2.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                }
            }
            .padding(.horizontal, 12)

            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 4), count: 7), spacing: 5) {
                ForEach(Array(monthGrid.enumerated()), id: \.offset) { _, date in
                    if let date {
                        DayCell(date: date, isCurrentMonth: isCurrentMonth(date))
                    } else {
                        Color.clear.frame(minHeight: 66)
                    }
                }
            }
            .padding(.horizontal, 10)

            Spacer(minLength: 0)

            HStack(spacing: 14) {
                Label("圆点：任务", systemImage: "circle.fill")
                Label("叶片：有专注记录", systemImage: "leaf.fill")
            }
            .font(.caption2)
            .foregroundStyle(.secondary)
            .padding(.bottom, 13)
        }
        .padding(.top, 14)
    }

    private var monthHeader: some View {
        HStack {
            Button {
                store.displayedMonth = Calendar.current.date(byAdding: .month, value: -1, to: store.displayedMonth) ?? store.displayedMonth
            } label: { Image(systemName: "chevron.left") }
                .buttonStyle(.plain)

            Spacer()
            Button {
                store.displayedMonth = Date().startOfDay
            } label: {
                Text(Self.monthFormatter.string(from: store.displayedMonth))
                    .font(.system(size: 19, weight: .semibold, design: .rounded))
            }
            .buttonStyle(.plain)
            Spacer()

            Button {
                store.displayedMonth = Calendar.current.date(byAdding: .month, value: 1, to: store.displayedMonth) ?? store.displayedMonth
            } label: { Image(systemName: "chevron.right") }
                .buttonStyle(.plain)
        }
        .padding(.horizontal, 18)
    }

    private var monthGrid: [Date?] {
        var calendar = Calendar.current
        calendar.firstWeekday = 2
        guard let interval = calendar.dateInterval(of: .month, for: store.displayedMonth),
              let days = calendar.range(of: .day, in: .month, for: store.displayedMonth) else { return [] }
        let first = interval.start
        let weekday = calendar.component(.weekday, from: first)
        let leading = (weekday + 5) % 7
        var result = Array<Date?>(repeating: nil, count: leading)
        for day in days {
            result.append(calendar.date(byAdding: .day, value: day - 1, to: first))
        }
        while result.count % 7 != 0 { result.append(nil) }
        return result
    }

    private func isCurrentMonth(_ date: Date) -> Bool {
        Calendar.current.isDate(date, equalTo: store.displayedMonth, toGranularity: .month)
    }

    private static let monthFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.dateFormat = "yyyy年 M月"
        return formatter
    }()
}

struct DayCell: View {
    @EnvironmentObject private var store: AppStore
    let date: Date
    let isCurrentMonth: Bool

    private var tasks: [TodoItem] { store.tasks(on: date) }
    private var focusSeconds: Int { store.focusSeconds(on: date) }

    var body: some View {
        Button {
            store.selectedDate = date.startOfDay
            store.selectedTab = .tasks
        } label: {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 3) {
                    Text("\(Calendar.current.component(.day, from: date))")
                        .font(.caption.weight(isToday ? .bold : .medium))
                        .foregroundStyle(isToday ? Color.white : (isCurrentMonth ? Color.primary : Color.secondary.opacity(0.5)))
                        .frame(width: 22, height: 22)
                        .background(isToday ? Color.accentColor : Color.clear)
                        .clipShape(Circle())
                    Spacer(minLength: 0)
                    if focusSeconds > 0 {
                        Image(systemName: "leaf.fill")
                            .font(.system(size: 8))
                            .foregroundStyle(Color.green)
                    }
                }

                VStack(alignment: .leading, spacing: 3) {
                    ForEach(tasks.prefix(2)) { task in
                        HStack(spacing: 3) {
                            Circle()
                                .fill(task.isCompleted ? Color.secondary.opacity(0.35) : Color.accentColor)
                                .frame(width: 4, height: 4)
                            Text(task.title)
                                .font(.system(size: 8.5))
                                .lineLimit(1)
                                .foregroundStyle(task.isCompleted ? .secondary : .primary)
                        }
                    }
                    if tasks.count > 2 {
                        Text("+\(tasks.count - 2)")
                            .font(.system(size: 8, weight: .semibold))
                            .foregroundStyle(.secondary)
                    }
                }
                Spacer(minLength: 0)
            }
            .padding(5)
            .frame(maxWidth: .infinity, minHeight: 66, alignment: .topLeading)
            .background(isToday ? Color.accentColor.opacity(0.08) : Color.primary.opacity(0.025))
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .opacity(isCurrentMonth ? 1 : 0.45)
        }
        .buttonStyle(.plain)
    }

    private var isToday: Bool { Calendar.current.isDateInToday(date) }
}
