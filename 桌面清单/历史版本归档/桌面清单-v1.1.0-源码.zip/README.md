# 桌面清单

一个本地优先的 macOS 桌面效率工具：ToDo、番茄钟、月视图、时间统计，以及由用户主动触发的 Mac 日历互传。

## 数据位置

`~/Library/Application Support/DeskFlow/data.json`

应用会在每次任务或计时变化后自动保存。右上角 `…` 可以导出完整 JSON 备份或 CSV 任务表。

## 构建

```bash
chmod +x build.sh
./build.sh
```

要求 macOS 14 或更高版本，以及 Apple Command Line Tools。
